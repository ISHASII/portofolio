module.exports = {
    plugins: [
        require("@tailwindcss/postcss"), // Menambahkan plugin Tailwind CSS untuk PostCSS
        require("autoprefixer"),
    ],
};
